# Introduction
Hyper Sudoku is a project that aims to solve Hyper Sudoku using Knuth's Algorithm X. It is also a final project for CS5800.

# Show

# Run the Project
1. Download the project
2. Install Node.js(We use Node.js 18.12.1 LTS)
3. Open terminal, enter the folder of the project
4. run `npm install`
5. run `npm start`
6. Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

# Author(Alphabetical Order)
Liyang Song, Na Yin, Xueyan Feng, Yun Cao